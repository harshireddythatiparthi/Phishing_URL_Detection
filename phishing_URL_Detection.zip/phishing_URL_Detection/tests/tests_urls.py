tests_urls = [
    ("https://www.google.com", "legitimate"),
    ("https://www.microsoft.com", "legitimate"),
    ("https://www.wikipedia.org", "legitimate"),
    ("https://www.github.com", "legitimate"),
    ("https://www.apple.com", "legitimate"),
    ("https://www.python.org", "legitimate"),

    ("http://secure-login-account.com/verify", "phishing"),
    ("http://paypal-security-check.com/login", "phishing"),
    ("http://free-gift-card-winner.com/claim", "phishing"),
    ("http://account-verify-now.com/update", "phishing"),
    ("http://login-confirm-security.com/signin", "phishing"),
    ("http://bank-account-alert.com/verify", "phishing"),
    ("http://password-reset-confirm.com/login", "phishing"),
    ("http://192.168.1.10/login", "phishing")
]


print("PHISHING URL DETECTION - TEST CASES")
print("=" * 50)

for number, (url, expected) in enumerate(tests_urls, start=1):
    print(f"{number}. {url}")
    print(f"   Expected: {expected}")
    print()