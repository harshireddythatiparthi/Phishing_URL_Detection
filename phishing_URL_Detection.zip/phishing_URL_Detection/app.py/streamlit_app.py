import streamlit as st
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from src.feature_extraction import extract_features

# PAGE SETTINGS
# ==========================================

st.set_page_config(
    page_title="Phishing URL Detection",
    page_icon="🛡️",
    layout="centered"
)


# ==========================================
# TITLE
# ==========================================

st.title("🛡️ Phishing URL Detection System")

st.write(
    "Enter a website URL below to check whether it is "
    "likely to be legitimate or phishing."
)


# ==========================================
# LOAD DATASET
# ==========================================

@st.cache_resource
def train_model():

    dataset_path = "data/phishing_urls.csv"

    df = pd.read_csv(dataset_path)

    # Extract features
    feature_data = []

    for url in df["url"]:
        feature_data.append(extract_features(url))

    X = pd.DataFrame(feature_data)

    # Convert labels
    y = df["label"].map({
        "legitimate": 0,
        "phishing": 1
    })

    # Train model using complete dataset
    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42
    )

    model.fit(X, y)

    return model


# ==========================================
# TRAIN MODEL
# ==========================================

model = train_model()


# ==========================================
# URL INPUT
# ==========================================

url = st.text_input(
    "Enter URL:",
    placeholder="Example: https://www.google.com"
)


# ==========================================
# CHECK URL
# ==========================================

if st.button("🔍 Check URL"):

    if url.strip() == "":
        st.warning("Please enter a URL.")

    else:

        # Extract features
        features = extract_features(url)

        # Convert to DataFrame
        feature_df = pd.DataFrame([features])

        # Prediction
        prediction = model.predict(feature_df)[0]

        # Probability
        probability = model.predict_proba(feature_df)[0]

        phishing_probability = probability[1] * 100
        legitimate_probability = probability[0] * 100


        # ======================================
        # DISPLAY RESULT
        # ======================================

        st.subheader("Detection Result")


        if prediction == 1:

            st.error("🚨 PHISHING URL")

            st.write(
                f"Phishing probability: "
                f"**{phishing_probability:.2f}%**"
            )

            st.write(
                "⚠️ This URL shows characteristics associated "
                "with phishing websites."
            )

        else:

            st.success("✅ LEGITIMATE URL")

            st.write(
                f"Legitimate probability: "
                f"**{legitimate_probability:.2f}%**"
            )

            st.write(
                "This URL appears legitimate based on "
                "the features analyzed."
            )


        # ======================================
        # SHOW ANALYZED FEATURES
        # ======================================

        st.subheader("🔎 URL Features Analyzed")

        feature_display = pd.DataFrame(
            {
                "Feature": list(features.keys()),
                "Value": list(features.values())
            }
        )

        st.dataframe(
            feature_display,
            use_container_width=True
        )