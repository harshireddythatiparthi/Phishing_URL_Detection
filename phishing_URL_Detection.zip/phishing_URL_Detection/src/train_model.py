import os
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

from feature_extraction import extract_features


# ==========================================
# PROJECT PATH
# ==========================================

PROJECT_FOLDER = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATASET_PATH = os.path.join(
    PROJECT_FOLDER,
    "data",
    "phishing_urls.csv"
)

# Save directly in the main project folder
MODEL_PATH = os.path.join(
    PROJECT_FOLDER,
    "phishing_model.pkl"
)


# ==========================================
# LOAD DATASET
# ==========================================

print("Loading dataset...")

df = pd.read_csv(DATASET_PATH)

print("Dataset loaded successfully!")
print("Number of URLs:", len(df))


# ==========================================
# EXTRACT FEATURES
# ==========================================

print("\nExtracting URL features...")

features = []

for url in df["url"]:
    features.append(extract_features(url))

X = pd.DataFrame(features)


# ==========================================
# CONVERT LABELS
# ==========================================

y = df["label"].map({
    "legitimate": 0,
    "phishing": 1
})


# ==========================================
# SPLIT DATA
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.30,
    random_state=42,
    stratify=y
)


# ==========================================
# TRAIN MODEL
# ==========================================

print("\nTraining Random Forest model...")

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)


# ==========================================
# PREDICT
# ==========================================

y_pred = model.predict(X_test)


# ==========================================
# EVALUATION
# ==========================================

accuracy = accuracy_score(y_test, y_pred)

precision = precision_score(
    y_test,
    y_pred,
    zero_division=0
)

recall = recall_score(
    y_test,
    y_pred,
    zero_division=0
)

f1 = f1_score(
    y_test,
    y_pred,
    zero_division=0
)

cm = confusion_matrix(y_test, y_pred)


# ==========================================
# SHOW RESULTS
# ==========================================

print("\n========================================")
print("       MODEL EVALUATION RESULTS")
print("========================================")

print(f"Accuracy : {accuracy:.2f}")
print(f"Precision: {precision:.2f}")
print(f"Recall   : {recall:.2f}")
print(f"F1 Score : {f1:.2f}")

print("\nConfusion Matrix:")
print(cm)