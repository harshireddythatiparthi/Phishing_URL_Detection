import re
import socket
from urllib.parse import urlparse


# Suspicious words commonly found in phishing URLs
SUSPICIOUS_WORDS = [
    "login",
    "verify",
    "verification",
    "account",
    "secure",
    "update",
    "confirm",
    "password",
    "bank",
    "signin",
    "free",
    "winner"
]


def has_ip_address(url):
    """Check whether the URL contains an IP address."""
    try:
        hostname = urlparse(url).hostname

        if hostname:
            socket.inet_aton(hostname)
            return 1

    except (socket.error, ValueError):
        pass

    return 0


def extract_features(url):
    """Extract useful features from a URL."""

    parsed_url = urlparse(url)

    hostname = parsed_url.hostname or ""

    features = {}

    # 1. URL length
    features["url_length"] = len(url)

    # 2. Number of dots
    features["dot_count"] = url.count(".")

    # 3. Number of special characters
    features["special_char_count"] = len(
        re.findall(r"[@?=&_%\-]", url)
    )

    # 4. HTTPS usage
    features["has_https"] = 1 if parsed_url.scheme == "https" else 0

    # 5. IP address in URL
    features["has_ip"] = has_ip_address(url)

    # 6. Number of subdomains
    hostname_parts = hostname.split(".") if hostname else []
    features["subdomain_count"] = max(len(hostname_parts) - 2, 0)

    # 7. Suspicious keywords
    url_lower = url.lower()

    suspicious_count = sum(
        1 for word in SUSPICIOUS_WORDS
        if word in url_lower
    )

    features["suspicious_keyword_count"] = suspicious_count

    # 8. URL contains @ symbol
    features["has_at_symbol"] = 1 if "@" in url else 0

    # 9. URL contains hyphen
    features["has_hyphen"] = 1 if "-" in hostname else 0

    return features