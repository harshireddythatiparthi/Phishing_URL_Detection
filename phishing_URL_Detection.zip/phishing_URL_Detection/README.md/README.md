# Phishing URL Detection System

## 1. Project Description

The Phishing URL Detection System is a cybersecurity project that analyzes a given URL and predicts whether it is legitimate or potentially phishing.

The system extracts important characteristics from the URL, such as URL length, number of dots, HTTPS usage, IP address usage, special characters, suspicious keywords, and subdomain-related characteristics.

A Machine Learning model is used to classify the URL as:

- LEGITIMATE
- PHISHING

The application provides the prediction through a simple Streamlit web interface.

---

## 2. Student Details

Student Name: Thatiparthi Harshitha

Department: Artificial Intelligence and Machine Learning (AIML)

Semester: 7th

College: Methodist College of Engineering and Technology

Batch: 2027

---

## 3. Objectives

The main objectives of this project are:

1. Accept a URL as input from the user.
2. Extract useful URL-based features.
3. Identify suspicious characteristics of URLs.
4. Use Machine Learning for URL classification.
5. Classify URLs as legitimate or phishing.
6. Display the extracted URL features and prediction.
7. Evaluate the model using accuracy, precision, recall, F1-score and confusion matrix.

---

## 4. Technology Stack

### Programming Language
- Python 3.13

### Libraries
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn
- Joblib
- Streamlit

### Development Tool
- Visual Studio Code

### Operating System
- Windows

---

## 5. Project Structure

```text
phishing_URL_Detection/
│
├── data/
│   └── phishing_urls.csv
│
├── models/
│
├── reports/
│   └── test_results.txt
│
├── screenshots/
│
├── src/
│   ├── feature_extraction.py
│   └── train_model.py
│
├── tests/
│   └── tests_urls.py
│
├── app.py
├── README.md
└── requirements.txt
````

---

## 6. Important Modules

### app.py

Runs the Streamlit web application and provides the user interface for entering URLs and viewing predictions.

### feature_extraction.py

Extracts meaningful characteristics from URLs for analysis.

### train_model.py

Loads the dataset, trains the Machine Learning model and evaluates its performance.

### tests_urls.py

Contains test URLs used to verify the project with legitimate and phishing-like examples.

### phishing_urls.csv

Contains the labelled URL dataset used for training and testing.

---

## 7. URL Features

The system considers URL characteristics such as:

* URL length
* Number of dots
* HTTPS usage
* IP address usage
* Special characters
* Suspicious keywords
* Subdomain characteristics
* Other selected URL properties

These features help the Machine Learning model identify suspicious URL patterns.

---

## 8. Machine Learning

The project uses a Machine Learning classification approach.

A Random Forest classifier is used for classification.

The general workflow is:

URL Input
↓
Feature Extraction
↓
Feature Values
↓
Machine Learning Model
↓
Prediction
↓
LEGITIMATE / PHISHING

---

## 9. Installation

Make sure Python is installed.

Open PowerShell in the project folder:

```powershell
cd C:\Users\ADMIN\Documents\phishing_URL_Detection
```

Install the required libraries:

```powershell
python -m pip install pandas numpy scikit-learn matplotlib seaborn streamlit joblib
```

---

## 10. Run the Model Training

Run:

```powershell
python src\train_model.py
```

The program loads the dataset, trains the model and displays evaluation results.

---

## 11. Run the Web Application

Run:

```powershell
python -m streamlit run app.py
```

The Streamlit application will open in the browser.

The local application normally runs at:

```text
http://localhost:8501
```

---

## 12. Sample Input

### Legitimate URL

```text
https://www.google.com
```

Expected classification:

```text
LEGITIMATE
```

### Phishing-like URL

```text
http://secure-login-account.com/verify
```

Expected classification:

```text
PHISHING
```

---

## 13. Testing

The project contains 14 test URLs.

Test categories include:

* Legitimate website URLs
* HTTPS URLs
* Suspicious login URLs
* Account verification URLs
* Suspicious keywords
* IP-address-based URLs

The test cases are stored in:

```text
tests/tests_urls.py
```

---

## 14. Model Evaluation

The model was evaluated using:

* Accuracy
* Precision
* Recall
* F1-score
* Confusion Matrix

Observed evaluation output:

```text
Accuracy  : 1.00
Precision : 1.00
Recall    : 1.00
F1 Score  : 1.00
```

Confusion Matrix:

```text
[[3 0]
 [0 2]]
```

These values are based on the small sample dataset used in this project.

---

## 15. Screenshots

The `screenshots` folder contains screenshots showing:

* Application interface
* Legitimate URL prediction
* Phishing URL prediction
* Extracted URL features
* Model evaluation
* Test cases
* Project structure

---

## 16. Dataset

The project uses a labelled URL dataset containing legitimate and phishing URL samples.

The dataset is stored in:

```text
data/phishing_urls.csv
```

The dataset is used for feature extraction, training and evaluation.

---

## 17. Limitations

1. The current dataset is small and is mainly suitable for project demonstration.
2. Real-world phishing URLs can change frequently.
3. A Machine Learning model may produce false positives or false negatives.
4. The evaluation results may change when a larger and more diverse dataset is used.
5. The system should not be treated as a replacement for professional security solutions.

---

## 18. Future Scope

The project can be improved by:

* Using a larger real-world URL dataset.
* Adding more URL and domain-based features.
* Using additional Machine Learning models.
* Adding real-time threat intelligence.
* Improving false-positive and false-negative detection.
* Adding a more detailed explanation of why a URL was classified as suspicious.
* Deploying the application as a web-based cybersecurity service.

---

## 19. Conclusion

The Phishing URL Detection System demonstrates how Machine Learning and URL feature analysis can be used to identify potentially phishing URLs.

The system accepts a URL, extracts relevant characteristics, applies a classification model and provides a clear prediction.

The project also includes testing, model evaluation, screenshots and documentation to demonstrate the working implementation.

---

## 20. Project Author

Thatiparthi Harshitha

Artificial Intelligence and Machine Learning (AIML)

Methodist College of Engineering and Technology

2027
